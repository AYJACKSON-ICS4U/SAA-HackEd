function attachHandler(){
  document.getElementById("loginButton").addEventListener("click", login);
}

