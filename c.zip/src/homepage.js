function attachHandler(){
  document.getElementById("makeNewDeck").addEventListener("click", createDeckPage);
  loadDecks();
  
}

