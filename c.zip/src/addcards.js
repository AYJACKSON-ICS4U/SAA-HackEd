function attachHandler(){
  document.getElementById("addToDeck").addEventListener("click", addToDeck);
  document.getElementById("done").addEventListener("click", loadDecks);
}

