function attachHandler(){
  document.getElementById("createDeckButton").addEventListener("click", createDeck);
}

