let userData;
let currentDeck = 0; 
let right_answers = 0; 

async function createDeck (){
  const deck = {
    deckName : document.getElementById("deckName").value, 
    deckDescription : document.getElementById("deckDescription").value
  }
  const ud = (JSON.parse(localStorage.getItem("currentUser")));
  await createSet(deck.deckName, deck.deckDescription, ud._id).then(async()=>{
    userData = await getUserData(ud.login.username);
    localStorage.setItem('currentUser', userData);
  currentDeck = userData.sets.length - 1;
    localStorage.setItem('currentDeck', currentDeck)
  });

}

function loadDecks(){
  const dummyDecks = [];
  dummyDecks.push({
    title: "Physics",
    description: "Physics cards"
  }
  );
  dummyDecks.push({
    title: "Biology",
    description: "Botany Plants"
  }
  );

  //userData.sets[currentDeck].title
  //userData.sets[currentDeck].description
  const deckContainer = document.getElementById("deck-container");
    for(var i = 0; i < dummyDecks.length; i++){
    deckContainer.innerHTML+=`<div class = "mydeck">
    <div class="card border-light mb-3" style="max-width: 18rem;">
        <div class="card-header"><a href="carddisplay.html">${dummyDecks[i].title}</a></div>
        <div class="card-body">
          <p class="card-text">${dummyDecks[i].description}</p>
        </div>
      </div>
    </div>`
    }
  }

  function loadCards() {
    const dummyCards = [];
    dummyCards.push({
       Physics: {
        term: "Physics",
      definition: "Physics cards"
       }
    }
    ),
    dummyCards.push({
      Physics: {
      term: "Biology",
      definition: "Botany Plants"
    } 
    }
    ), 
    dummyCards.push({
      Physics: {
      term: "gibberish",
      definition: "more gibberish"
    } 
    }
    );
    //sets[currentDeck].title.[currentCard].term
    const cardContainer = document.getElementById("card-container");
    for(var i = 0; i < dummyCards.length; i++){
    cardContainer.innerHTML+=`<div class="flash_card">
    <div class="card" style="width: 20rem; height: 20rem">
      <div class="card-body">
        <h5 class="card-title">${dummyCards[i].Physics.term}</h5>
        <div class="text-center">
          <button class="btn btn-primary">Flip</button>
        </div>
      </div>
    </div>
  </div>`
    }
   
  }
function addToDeck() {
  const card = {
    term : document.getElementById("term").value, 
    definition : document.getElementById("definition").value
  }
  createCard(card.Definition, card.term, userData.sets[currentDeck]._id,userData._id);
  userData = getUserData(userData.login.username);
}
 async function login(){
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value; 
    userData = await verifyLogin(username,password);
    console.log(userData);
    localStorage.setItem('currentUser', JSON.stringify(userData));
    if(userData == 0){
      alert("Invalid login");
    }  
    else {
      document.location = "homepage.html";
    }
}

function grade() {
  right_answers += 1; 
  console.log(right_answers);
}

function createDeckPage() {
  document.location = "createdeck.html";
}

async function submit(){
  console.log("yes");
  const username = document.getElementById("username").value; 
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value; 

  await createUser(username,email,password).then(async()=>{
     userData = await getUserData(username);
  });
  document.location = "homepage.html";
 }


async function getUserData(username) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/getuserdata?username=" + username;
  const user = await fetch(url);
  const userInfo = await user.json();
  return userInfo;
}

async function createUser(username, email, password) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/createuser?username=" + username + "&password="+password+"&email="+email;
  console.log(url);
  const createuser = await fetch(url);
  const created = await createuser.text();
console.log(created);
  return created;
}

async function createSet(title, description, owner) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/createset?title=" + title + "&description="+description+"&owner="+owner;
  const createSet = await fetch(url);
  const createdset = await createSet.json();
  return createdset;
}

async function createCard(term, definition, owner) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/createcard?term=" + term + "&definition="+definition+"&owner="+owner;
  const createCard = await fetch(url);
  return createCard;
}

async function deleteUser(username) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/deleteuser?username=" + username;
  const deleteUser = await fetch(url);
  return deleteUser;
}

async function verifyLogin(username, password) {
  const url = "https://pacific-inlet-67317.herokuapp.com/api/verifylogin?username=" + username + "&password=" + password;
  const verify = await fetch(url);
  const ud = await verify.json();
  return ud;
}

